module.exports = {
  botName: 'DPK BOT',
  clanName: 'DPK FAMILY - DARK PURGE KINGDOM',
  // Nimewo bot la (san +, san espas)
  botNumber: '50940053612',
  // Nimewo mèt la (owner) - chanje si li diferan
  ownerNumber: '50940053612',
  prefix: '.',
  image: './media/dpk.png',
  slogan: 'One clan, one family, one domination.'
}
