const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers
} = require('@whiskeysockets/baileys')
const pino = require('pino')
const fs = require('fs')
const config = require('./config')

const startTime = Date.now()
const logo = () => fs.readFileSync(config.image)

const uptime = () => {
  const s = Math.floor((Date.now() - startTime) / 1000)
  return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${s % 60}s`
}

const menuText = (p) => `╔═══════════════════╗
   🟣 *${config.botName}* 🟣
   _${config.clanName}_
╚═══════════════════╝

⚔️ *COMMANDES GÉNÉRALES*
• ${p}menu — Montre menu a
• ${p}ping — Vitès bot la
• ${p}alive — Bot la aktif?
• ${p}owner — Kontak mèt la
• ${p}runtime — Tan bot la ap mache

👑 *GROUPE*
• ${p}tagall — Mansyone tout moun
• ${p}hidetag <tèks> — Mesaj kache
• ${p}link — Lyen gwoup la
• ${p}kick @user — Retire yon moun (admin)
• ${p}promote @user — Mete admin
• ${p}demote @user — Retire admin
• ${p}group open|close — Louvri/fèmen gwoup

🔥 _${config.slogan}_
🔗 *Join the DPK Empire*`

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('./session')
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    auth: state,
    printQRInTerminal: false,
    browser: Browsers.ubuntu('Chrome'),
    markOnlineOnConnect: true
  })

  // Koneksyon ak nimewo (pairing code)
  if (!sock.authState.creds.registered) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(config.botNumber)
        console.log('\n🟣 PAIRING CODE DPK BOT :', code?.match(/.{1,4}/g)?.join('-') || code)
        console.log('WhatsApp > Appareils connectés > Connecter avec un numéro de téléphone\n')
      } catch (e) {
        console.log('Erè pairing code:', e.message)
      }
    }, 3000)
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      console.log(`✅ ${config.botName} konekte!`)
    } else if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode
      if (code === DisconnectReason.loggedOut) {
        console.log('❌ Dekonekte. Efase dosye ./session epi relanse.')
      } else {
        console.log('🔄 Rekonekte...')
        startBot()
      }
    }
  })

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    const m = messages[0]
    if (!m?.message || m.key.remoteJid === 'status@broadcast') return

    const jid = m.key.remoteJid
    const isGroup = jid.endsWith('@g.us')
    const sender = isGroup ? (m.key.participant || m.participant) : jid
    const senderNum = (sender || '').split('@')[0].split(':')[0]
    const isOwner = m.key.fromMe || senderNum === config.ownerNumber

    const msg = m.message
    const text =
      msg.conversation ||
      msg.extendedTextMessage?.text ||
      msg.imageMessage?.caption ||
      msg.videoMessage?.caption || ''

    if (!text.startsWith(config.prefix)) return
    const [cmdRaw, ...args] = text.slice(config.prefix.length).trim().split(/\s+/)
    const cmd = cmdRaw.toLowerCase()
    const reply = (t) => sock.sendMessage(jid, { text: t }, { quoted: m })

    // Enfòmasyon gwoup
    let meta, admins = [], isAdmin = false, botIsAdmin = false
    if (isGroup) {
      meta = await sock.groupMetadata(jid)
      admins = meta.participants.filter(p => p.admin).map(p => p.id)
      isAdmin = admins.includes(sender) || isOwner
      const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'
      botIsAdmin = admins.includes(botId)
    }
    const needGroup = () => !isGroup && (reply('⚠️ Kòmand sa a pou gwoup sèlman.'), true)
    const needAdmin = () => !isAdmin && (reply('⛔ Admin sèlman.'), true)
    const needBotAdmin = () => !botIsAdmin && (reply('⚠️ Mete bot la admin dabò.'), true)

    try {
      switch (cmd) {
        case 'menu':
        case 'help':
          await sock.sendMessage(jid, { image: logo(), caption: menuText(config.prefix) }, { quoted: m })
          break

        case 'ping': {
          const t = Date.now()
          await reply('🏓 Pong...')
          await reply(`⚡ Vitès: *${Date.now() - t} ms*`)
          break
        }

        case 'alive':
          await sock.sendMessage(jid, {
            image: logo(),
            caption: `🟣 *${config.botName}* aktif!\n⏱️ Uptime: ${uptime()}\n\n_${config.slogan}_`
          }, { quoted: m })
          break

        case 'runtime':
          await reply(`⏱️ ${config.botName} ap mache depi: *${uptime()}*`)
          break

        case 'owner':
          await sock.sendMessage(jid, {
            contacts: {
              displayName: 'DPK Owner',
              contacts: [{
                vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:DPK Owner\nTEL;type=CELL;waid=${config.ownerNumber}:+${config.ownerNumber}\nEND:VCARD`
              }]
            }
          }, { quoted: m })
          break

        case 'tagall': {
          if (needGroup() || needAdmin()) break
          const ids = meta.participants.map(p => p.id)
          const list = ids.map(id => `🟣 @${id.split('@')[0]}`).join('\n')
          await sock.sendMessage(jid, {
            text: `👑 *DPK FAMILY — APPEL GÉNÉRAL*\n${args.join(' ')}\n\n${list}`,
            mentions: ids
          }, { quoted: m })
          break
        }

        case 'hidetag': {
          if (needGroup() || needAdmin()) break
          await sock.sendMessage(jid, {
            text: args.join(' ') || '👑 DPK',
            mentions: meta.participants.map(p => p.id)
          })
          break
        }

        case 'link': {
          if (needGroup() || needAdmin() || needBotAdmin()) break
          const code = await sock.groupInviteCode(jid)
          await reply(`🔗 https://chat.whatsapp.com/${code}`)
          break
        }

        case 'kick':
        case 'promote':
        case 'demote': {
          if (needGroup() || needAdmin() || needBotAdmin()) break
          const target = msg.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
            || msg.extendedTextMessage?.contextInfo?.participant
          if (!target) return reply(`Mansyone yon moun: ${config.prefix}${cmd} @user`)
          const action = cmd === 'kick' ? 'remove' : cmd
          await sock.groupParticipantsUpdate(jid, [target], action)
          await reply('✅ Fèt.')
          break
        }

        case 'group': {
          if (needGroup() || needAdmin() || needBotAdmin()) break
          if (args[0] === 'close') {
            await sock.groupSettingUpdate(jid, 'announcement')
            await reply('🔒 Gwoup la fèmen.')
          } else if (args[0] === 'open') {
            await sock.groupSettingUpdate(jid, 'not_announcement')
            await reply('🔓 Gwoup la louvri.')
          } else {
            await reply(`Itilize: ${config.prefix}group open | close`)
          }
          break
        }
      }
    } catch (e) {
      console.log('Erè kòmand:', e)
      reply('❌ Gen yon erè.')
    }
  })
}

startBot()
