# 🟣 DPK BOT — Dark Purge Kingdom (WhatsApp MD)

## Enstalasyon
1. Enstale Node.js 18+ (Termux: `pkg install nodejs git`)
2. Nan dosye a:
   ```
   npm install
   npm start
   ```
3. Bot la ap montre yon **PAIRING CODE** nan terminal la.
4. Sou WhatsApp bot la (+50940053612): Paramèt → Appareils connectés → Connecter avec un numéro de téléphone → mete kòd la.

## Konfigirasyon
Modifye `config.js` (nimewo, owner, prefix, non).
Imaj bot la: `media/dpk.png`.

## Kòmand
.menu .ping .alive .runtime .owner .tagall .hidetag .link .kick .promote .demote .group open|close

⚠️ Si w dekonekte: efase dosye `session/` epi relanse.
